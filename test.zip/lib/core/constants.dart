import 'dart:ui';

const kPrimaryColor = Color(0xff100b20);
const kTransitionDuration = Duration(milliseconds: 250);
const kGtSextraFine = 'GT Sectra Fine';
